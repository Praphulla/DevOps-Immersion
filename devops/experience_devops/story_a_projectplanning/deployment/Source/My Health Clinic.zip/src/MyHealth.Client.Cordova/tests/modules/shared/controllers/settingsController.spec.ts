﻿/// <reference path="../../../../content/app/typings/jasmine/jasmine.d.ts" />

describe('settingsController Test', (): void => {

    // Module initialization
    beforeEach(function () {

    });

    // Mock creation
    beforeEach(function () {
    });

    it('can be initialized', (): void => {

    });

    it('test the truth', (): void => {
        expect(true).toBeTruthy();
    });

});