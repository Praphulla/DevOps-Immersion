﻿
namespace MyHealth.Client.Core
{
    public enum InternationalUnit
    {
        Ml = 1,
        Mg = 2
    }
}
