﻿using System;

namespace MyHealth.Client.Core.Services
{
    public interface IHockeyAppFeedbackService
    {
        void LaunchHockeyAppFeedback();
    }
}

