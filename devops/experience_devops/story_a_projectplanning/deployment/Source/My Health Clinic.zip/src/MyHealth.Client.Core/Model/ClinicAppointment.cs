﻿
namespace MyHealth.Client.Core.Model
{
    public class ClinicAppointment : Appointment
    {
        public int RoomNumber { get; set; }

    }
}
