using Cirrious.CrossCore.Plugins;

namespace MyHealth.Client.Droid.Bootstrap
{
    public class PictureChooserPluginBootstrap
        : MvxPluginBootstrapAction<MvvmCross.Plugins.PictureChooser.PluginLoader>
    {
    }
}