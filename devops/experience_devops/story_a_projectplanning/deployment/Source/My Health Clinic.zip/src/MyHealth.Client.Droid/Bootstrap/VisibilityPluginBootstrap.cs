using Cirrious.CrossCore.Plugins;

namespace MyHealth.Client.Droid.Bootstrap
{
    public class VisibilityPluginBootstrap
        : MvxPluginBootstrapAction<MvvmCross.Plugins.Visibility.PluginLoader>
    {
    }
}