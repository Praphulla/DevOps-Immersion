using Cirrious.CrossCore.Plugins;

namespace MyHealth.Client.iOS.Bootstrap
{
    public class PictureChooserPluginBootstrap
        : MvxLoaderPluginBootstrapAction<MvvmCross.Plugins.PictureChooser.PluginLoader, MvvmCross.Plugins.PictureChooser.Touch.Plugin>
    {
    }
}