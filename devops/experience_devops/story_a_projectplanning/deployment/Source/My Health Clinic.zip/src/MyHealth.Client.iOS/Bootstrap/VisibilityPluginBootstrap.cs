using Cirrious.CrossCore.Plugins;

namespace MyHealth.Client.iOS.Bootstrap
{
    public class VisibilityPluginBootstrap
        : MvxLoaderPluginBootstrapAction<MvvmCross.Plugins.Visibility.PluginLoader, MvvmCross.Plugins.Visibility.Touch.Plugin>
    {
    }
}